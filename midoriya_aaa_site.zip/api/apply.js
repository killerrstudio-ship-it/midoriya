const fetch = require('node-fetch');
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({error:'Method not allowed'});
  const payload = req.body || {};
  const webhook = process.env.DISCORD_WEBHOOK_APPLICATIONS;
  const content = {
    username: "MIDORIYA - Applications",
    embeds: [{
      title: "New Application",
      color: 5793266,
      fields: Object.keys(payload).map(k=>({name:k, value:String(payload[k]).slice(0,1000), inline:false})),
      timestamp: new Date()
    }]
  };
  if (webhook) {
    try{
      await fetch(webhook, {method:'POST', body:JSON.stringify(content), headers:{'Content-Type':'application/json'}});
      return res.status(200).json({ok:true});
    }catch(e){
      console.error(e);
    }
  }
  // fallback: store locally
  const fs = require('fs');
  const p = './data/applications.json';
  const arr = fs.existsSync(p) ? JSON.parse(fs.readFileSync(p)) : [];
  arr.push({time:new Date(), payload});
  fs.mkdirSync('./data', {recursive:true});
  fs.writeFileSync(p, JSON.stringify(arr, null, 2));
  return res.status(200).json({ok:true, stored:true});
};
